import re
from collections import Counter
import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from nltk.stem import PorterStemmer, WordNetLemmatizer

st.set_page_config(page_title="NLP Text Analyzer", page_icon="📝", layout="wide")

STOP_WORDS = set("""
a an the and or but if while is am are was were be been being have has had do does did
of to in on at for from by with about as into through during before after above below
between out against over under again further then once here there when where why how all
any both each few more most other some such no nor not only own same so than too very
can will just should now i me my we our you your he she it they them this that these those
what which who whom their his her its up down off
""".split())

def words(text):
    return re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?", text.lower())

def sentences(text):
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s.strip()]

def clean_text(text, remove_numbers=True, remove_punctuation=True):
    result = text
    if remove_numbers:
        result = re.sub(r"\d+", " ", result)
    if remove_punctuation:
        result = re.sub(r"[^\w\s']", " ", result)
    return re.sub(r"\s+", " ", result).strip()

def stem_and_lemma(token_list):
    stemmer = PorterStemmer()
    lemmatizer = WordNetLemmatizer()
    rows = []
    for word in token_list:
        try:
            lemma = lemmatizer.lemmatize(word)
        except LookupError:
            lemma = word
        rows.append({"Word": word, "Stem": stemmer.stem(word), "Lemma": lemma})
    return pd.DataFrame(rows)

def pos_tag_text(token_list):
    try:
        import nltk
        try:
            return nltk.pos_tag(token_list)
        except LookupError:
            for resource in ("averaged_perceptron_tagger_eng", "averaged_perceptron_tagger"):
                try:
                    nltk.download(resource, quiet=True)
                except Exception:
                    pass
            return nltk.pos_tag(token_list)
    except Exception:
        tags = []
        for w in token_list:
            if w.endswith("ly"): tag = "RB (adverb heuristic)"
            elif w.endswith(("ing", "ed")): tag = "VB (verb heuristic)"
            elif w.endswith(("ous", "ful", "ive", "able", "al")): tag = "JJ (adjective heuristic)"
            else: tag = "NN (noun/default heuristic)"
            tags.append((w, tag))
        return tags

def extract_entities(text):
    # Lightweight fallback NER: proper-name sequences, no external model required.
    matches = re.findall(r"\b(?:[A-Z][a-z]+)(?:\s+[A-Z][a-z]+)*\b", text)
    ignore = {"The", "A", "An", "In", "On", "At", "This", "That", "I"}
    entities = [m for m in matches if m.split()[0] not in ignore]
    return sorted(set(entities))

st.title("📝 NLP Text Analyzer & Feature Engineering Toolkit")
st.caption("Mini project based on Text Pre-processing and Text Representation syllabus topics.")
st.info("Enter your own text or load the sample. The app demonstrates common NLP preprocessing and feature-extraction methods for learning purposes.")

sample = (
    "Natural Language Processing helps computers understand human language. "
    "Students use NLP for text classification, sentiment analysis, and job recommendation systems. "
    "Chandigarh University teaches Artificial Intelligence and Machine Learning. "
    "The students are learning, analyzing documents, and building useful applications in 2026."
)
left, right = st.columns([3, 1])
with left:
    text_input = st.text_area("Enter document text", value=sample, height=180)
with right:
    st.write("**Quick actions**")
    if st.button("Use sample text", use_container_width=True):
        st.session_state["reset_sample"] = True
        st.rerun()
    st.write("**Text statistics**")
    st.metric("Characters", len(text_input))
    st.metric("Words", len(words(text_input)))
    st.metric("Sentences", len(sentences(text_input)))

if not text_input.strip():
    st.warning("Enter some text to start analyzing.")
    st.stop()

tokens = words(text_input)
filtered_tokens = [w for w in tokens if w not in STOP_WORDS]
tabs = st.tabs([
    "1. Tokenization", "2. Stop Words", "3. Stem & Lemma",
    "4. POS & NER", "5. Bag-of-Words", "6. TF-IDF",
    "7. N-grams", "8. Regex & Summary"
])

with tabs[0]:
    st.subheader("Tokenization and word frequency")
    c1, c2 = st.columns(2)
    with c1:
        st.write("**Sentence tokens**")
        st.dataframe(pd.DataFrame({"Sentence": sentences(text_input)}), use_container_width=True, hide_index=True)
    with c2:
        st.write("**Word tokens**")
        st.write(tokens)
    freq = Counter(tokens)
    freq_df = pd.DataFrame(freq.most_common(20), columns=["Word", "Frequency"])
    st.write("**Top word frequencies**")
    st.dataframe(freq_df, use_container_width=True, hide_index=True)
    if not freq_df.empty:
        fig, ax = plt.subplots(figsize=(9, 3.5))
        ax.bar(freq_df["Word"], freq_df["Frequency"])
        ax.set_ylabel("Frequency")
        ax.set_title("Top 20 Word Frequencies")
        ax.tick_params(axis="x", rotation=45)
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

with tabs[1]:
    st.subheader("Stop-word removal")
    st.write("Stop words are common words that are often removed to focus on informative terms.")
    a, b = st.columns(2)
    with a:
        st.metric("Tokens before", len(tokens))
        st.write(tokens)
    with b:
        st.metric("Tokens after", len(filtered_tokens))
        st.write(filtered_tokens)
    st.write("**Comparison**")
    st.dataframe(pd.DataFrame([
        {"Stage": "Original tokens", "Count": len(tokens)},
        {"Stage": "After stop-word removal", "Count": len(filtered_tokens)},
        {"Stage": "Tokens removed", "Count": len(tokens)-len(filtered_tokens)}
    ]), use_container_width=True, hide_index=True)

with tabs[2]:
    st.subheader("Stemming vs lemmatization")
    st.caption("Stemming cuts word endings; lemmatization attempts to return a dictionary base form.")
    st.dataframe(stem_and_lemma(tokens[:150]), use_container_width=True, hide_index=True)

with tabs[3]:
    st.subheader("Part-of-speech tagging")
    st.caption("POS tags are generated with NLTK when its tagger data is available; a heuristic fallback is used otherwise.")
    pos_rows = pos_tag_text(tokens[:150])
    st.dataframe(pd.DataFrame(pos_rows, columns=["Word", "POS tag"]), use_container_width=True, hide_index=True)
    st.subheader("Named Entity Recognition (NER) demonstration")
    st.caption("This built-in lightweight demonstration extracts capitalized name-like phrases. It is not a full trained NER model.")
    entities = extract_entities(text_input)
    st.write(entities if entities else "No name-like entities detected.")

with tabs[4]:
    st.subheader("Bag-of-Words document-term matrix")
    docs_text = st.text_area(
        "Enter multiple documents (one document per line)",
        value="Natural language processing analyzes text\nMachine learning learns from data\nText analysis uses natural language tools",
        height=110,
        key="bow_docs"
    )
    docs = [d.strip() for d in docs_text.splitlines() if d.strip()]
    if docs:
        try:
            vec = CountVectorizer(stop_words="english")
            matrix = vec.fit_transform(docs)
            bow_df = pd.DataFrame(matrix.toarray(), columns=vec.get_feature_names_out(),
                                  index=[f"Document {i+1}" for i in range(len(docs))])
            st.dataframe(bow_df, use_container_width=True)
            st.download_button("Download BoW matrix CSV", bow_df.to_csv().encode("utf-8"),
                               file_name="bag_of_words_matrix.csv", mime="text/csv")
        except ValueError:
            st.warning("Add more meaningful words to build the matrix.")

with tabs[5]:
    st.subheader("TF-IDF keyword extraction")
    docs_tfidf = st.text_area(
        "Enter documents (one document per line)",
        value="NLP helps analyze human language and text.\nMachine learning models learn patterns from data.\nNLP and machine learning are used in text analytics.",
        height=110,
        key="tfidf_docs"
    )
    docs = [d.strip() for d in docs_tfidf.splitlines() if d.strip()]
    if docs:
        try:
            tfidf = TfidfVectorizer(stop_words="english")
            mat = tfidf.fit_transform(docs)
            tfidf_df = pd.DataFrame(mat.toarray(), columns=tfidf.get_feature_names_out(),
                                    index=[f"Document {i+1}" for i in range(len(docs))])
            st.dataframe(tfidf_df.round(3), use_container_width=True)
            doc_choice = st.selectbox("Show top keywords for", list(range(1, len(docs)+1)),
                                      format_func=lambda x: f"Document {x}")
            scores = tfidf_df.iloc[doc_choice-1].sort_values(ascending=False).head(10)
            st.write(pd.DataFrame({"Keyword": scores.index, "TF-IDF score": scores.values.round(3)}))
            st.download_button("Download TF-IDF matrix CSV", tfidf_df.to_csv().encode("utf-8"),
                               file_name="tfidf_matrix.csv", mime="text/csv")
        except ValueError:
            st.warning("Add more meaningful words to calculate TF-IDF.")

with tabs[6]:
    st.subheader("N-grams")
    n = st.select_slider("Select n-gram size", options=[1, 2, 3], value=2)
    tokens_clean = words(clean_text(text_input))
    grams = list(zip(*[tokens_clean[i:] for i in range(n)])) if len(tokens_clean) >= n else []
    gram_counts = Counter([" ".join(g) for g in grams])
    gram_df = pd.DataFrame(gram_counts.most_common(30), columns=[f"{n}-gram", "Frequency"])
    st.write(gram_df if not gram_df.empty else "Not enough tokens for this n-gram size.")
    st.caption("Skip-grams are word pairs with gaps. Example: in 'NLP makes text useful', a skip-gram may pair 'NLP' and 'useful'.")

with tabs[7]:
    st.subheader("Regular-expression cleaning")
    remove_nums = st.checkbox("Remove numbers", value=True)
    remove_punct = st.checkbox("Remove punctuation", value=True)
    cleaned = clean_text(text_input, remove_numbers=remove_nums, remove_punctuation=remove_punct)
    st.text_area("Cleaned text", value=cleaned, height=100)
    st.write("**Summary**")
    summary = pd.DataFrame([
        {"Metric": "Characters", "Value": len(text_input)},
        {"Metric": "Sentences", "Value": len(sentences(text_input))},
        {"Metric": "Word tokens", "Value": len(tokens)},
        {"Metric": "Unique words", "Value": len(set(tokens))},
        {"Metric": "After stop-word removal", "Value": len(filtered_tokens)},
        {"Metric": "Name-like entities", "Value": len(extract_entities(text_input))}
    ])
    st.dataframe(summary, use_container_width=True, hide_index=True)
    st.download_button("Download analysis summary CSV", summary.to_csv(index=False).encode("utf-8"),
                       file_name="text_analysis_summary.csv", mime="text/csv")

st.divider()
st.caption("Educational mini project. NER is a lightweight demonstration; results should not be treated as production-grade NLP output.")
