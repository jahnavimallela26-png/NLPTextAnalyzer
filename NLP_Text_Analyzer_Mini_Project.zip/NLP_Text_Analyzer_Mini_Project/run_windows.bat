@echo off
title NLP Text Analyzer
cd /d "%~dp0"
echo ===========================================
echo   NLP Text Analyzer - First-time setup
echo ===========================================
where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found. Install Python 3.10+ and enable "Add Python to PATH".
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  python -m venv .venv
)
echo Installing or checking required packages...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
  echo Package installation failed. Check internet connection and try again.
  pause
  exit /b 1
)
echo Starting application...
".venv\Scripts\python.exe" -m streamlit run app.py
pause
