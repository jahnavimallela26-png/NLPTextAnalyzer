# NLP Text Analyzer & Feature Engineering Toolkit

A beginner-friendly NLP mini project aligned with the Text Pre-processing and Text Representation syllabus.

## Features
- Sentence and word tokenization
- Word-frequency distribution and chart
- Stop-word removal and before/after comparison
- Porter stemming and WordNet lemmatization comparison
- Part-of-speech tagging (NLTK tagger when available, heuristic fallback otherwise)
- Lightweight proper-name extraction demo (not production NER)
- Regular-expression text cleaning
- Bag-of-Words document-term matrix and CSV export
- TF-IDF matrix, top-keyword view, and CSV export
- Unigram, bigram, and trigram frequency analysis
- Summary statistics and CSV export

## Requirements
- Python 3.10 or newer recommended
- Internet connection for the first setup (to install Python packages). NLTK tagger data may download on demand.

## Run on Windows
1. Extract the ZIP file.
2. Open the extracted `NLP_Text_Analyzer_Mini_Project` folder in VS Code.
3. Ensure Python is installed: open Terminal and run `python --version`.
4. Double-click `run_windows.bat`, or run these commands in PowerShell:

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   streamlit run app.py
   ```

5. A browser page should open. If it does not, open the URL printed in the terminal (usually `http://localhost:8501`).
6. Paste text or use the sample. Explore the tabs. BoW and TF-IDF tabs accept one document per line.

## Troubleshooting
- If `python` is not recognized, install Python from python.org and select **Add Python to PATH**, then reopen VS Code.
- If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` in that terminal, then activate the environment again. Alternatively run `run_windows.bat`.
- If port 8501 is busy, stop the other Streamlit process or run `python -m streamlit run app.py --server.port 8502`.
- Keep the terminal open while using the app; press `Ctrl+C` to stop it.

## Project scope / limitations
This is an educational prototype. The NER feature is a simple capitalized-phrase demonstration rather than a trained named-entity model. POS tagging uses NLTK data if available and a heuristic fallback if not. TF-IDF values depend on the set of documents supplied.
